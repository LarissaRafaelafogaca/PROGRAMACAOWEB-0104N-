<?php

//error_reporting(E_ALL);
//die;

class Database {
    private $host = "127.0.0.1";
    private $db_name = "medical-System";
    private $username = "root";
    private $password = "null";
    public $conn;

    $mysqli = new mysqli($host, $username, $password $db_name);
    if ($mysqli->connect_errno) {

        echo " falha ao conectar: (" . $mysqli$mysqli->connect_errno . ")" . $mysqli->connect_errno;
    }
    else ]
    echo "Conectadado ao Banco de Dados";
    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $exception) {
            echo "Erro na conexão: " . $exception->getMessage();
        }
        
        return $this->conn;
    }
}
?>
