<?php
// Número de colunas no rodapé (modifique conforme necessário)
$footer_columns = 3;

// Configuração básica
if ($footer_columns <= 0) {
    return; // Caso não haja colunas
}
?>

<aside class="footer-widgets widget-columns-<?php echo intval($footer_columns); ?>" role="complementary" aria-label="Rodapé">
    <?php
    // Loop para criar widgets dinamicamente
    for ($i = 1; $i <= $footer_columns; $i++) {
        ?>
        <div class="widget-column footer-widget-<?php echo $i; ?>">
            <h3>Widget <?php echo $i; ?></h3>
            <p>Conteúdo do Widget <?php echo $i; ?></p>
        </div>
        <?php
    }
    ?>
</aside>
<div class="footer-extra-content text-center">
    <p>© 2024 Clínica Fogaça. Todos os direitos reservados.</p>
</div>
