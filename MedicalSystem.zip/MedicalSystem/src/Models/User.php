namespace App\Models;

use App\Config\Database;

class User {
    private $db;
    
    public function __construct() {
        $this->db = Database::connect();
    }
    
    // Criar usuário com os novos campos
    public function create($username, $email, $password, $birthdate, $address) {
        $query = "INSERT INTO users (name, email, password, birthdate, address) 
                  VALUES (:name, :email, :password, :birthdate, :address)";
        
        $stmt = $this->db->prepare($query);
        
        // Associando os parâmetros à query
        $stmt->bindParam(':name', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', password_hash($password, PASSWORD_BCRYPT)); // Criptografando a senha
        $stmt->bindParam(':birthdate', $birthdate);
        $stmt->bindParam(':address', $address);
        
        // Executando a query e retornando o resultado
        return $stmt->execute();
    }
}
