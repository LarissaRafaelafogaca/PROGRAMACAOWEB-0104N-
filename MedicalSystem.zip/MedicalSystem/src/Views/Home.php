<?php
// Simulação de carregamento de imagens (substitua por consulta real ao banco de dados ou outro recurso).
$images = [
    ['url' => 'images/about.jpg', 'title' => 'Imagem 1'],
    ['url' => 'images/banner.jpg', 'title' => 'Imagem 2'],
    ['url' => 'images/contact.jpg', 'title' => 'Imagem 3'],
];

// Verifica se o diretório de imagens existe (criação para simular imagens, se necessário).
if (!is_dir('images')) {
    mkdir('images', 0777, true);
    // Gera imagens de exemplo (criação automática de imagens para teste).
    file_put_contents('images/image1.jpg', file_get_contents('https://via.placeholder.com/300x200?text=Imagem+1'));
    file_put_contents('images/image2.jpg', file_get_contents('https://via.placeholder.com/300x200?text=Imagem+2'));
    file_put_contents('images/image3.jpg', file_get_contents('https://via.placeholder.com/300x200?text=Imagem+3'));
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clínica Fogaça - Galeria</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .gallery img {
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center text-primary">Galeria de Imagens</h1>
        <?php if (count($images) > 0): ?>
            <div class="row gallery mt-4">
                <?php foreach ($images as $image): ?>
                    <div class="col-md-4 mb-4">
                        <img src="<?= htmlspecialchars($image['url']) ?>" alt="<?= htmlspecialchars($image['title']) ?>" class="img-fluid">
                        <p class="text-center mt-2"><?= htmlspecialchars($image['title']) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-center text-muted mt-4">Nenhuma imagem disponível.</p>
        <?php endif; ?>
    </div>
    <div class="text-center mt-5">
        <footer class="text-muted">&copy; 2024 Clínica Fogaça. Todos os direitos reservados.</footer>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
