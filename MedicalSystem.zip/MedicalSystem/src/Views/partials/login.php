<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clínica Fogaça - Login</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
        }
        h1 {
            font-size: 2rem;
            font-weight: bold;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
            color: #6c757d;
        }
    </style>
</head>
<body class="bg-light d-flex flex-column align-items-center justify-content-center min-vh-100">
    <!-- Conteúdo Principal -->
    <div class="card shadow-sm p-4" style="max-width: 400px; width: 100%;">
        <h1 class="text-center text-primary">Clínica Fogaça</h1>
        <h2 class="text-center text-secondary mb-4">Login</h2>
        <form id="loginForm" action="src/process-login.php" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Nome de Usuário</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Telefone</label>
                <input type="tel" class="form-control" id="phone" name="phone" pattern="^\([0-9]{2}\)\s?[0-9]{4,5}-[0-9]{4}$" placeholder="(XX) XXXXX-XXXX" required>
                <small class="form-text text-muted">Digite o telefone no formato (XX) XXXX-XXXX ou (XX) XXXXX-XXXX</small>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Senha</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Entrar</button>
        </form>
    </div>

    <!-- Rodapé -->
    <div class="footer">
        <p>&copy; 2024 Clínica Fogaça. Todos os direitos reservados.</p>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Validação com SweetAlert2 -->
    <script>
        document.getElementById('loginForm').addEventListener('submit', function (e) {
            const username = document.getElementById('username').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const password = document.getElementById('password').value.trim();

            // Validações
            if (!username || !email || !phone || !password) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Erro',
                    text: 'Por favor, preencha todos os campos!',
                });
            } else if (password.length < 6) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Atenção',
                    text: 'A senha deve ter pelo menos 6 caracteres!',
                });
            } else if (!phone.match(/^\([0-9]{2}\)\s?[0-9]{4,5}-[0-9]{4}$/)) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Erro',
                    text: 'Por favor, insira um número de telefone válido no formato (XX) XXXX-XXXX ou (XX) XXXXX-XXXX',
                });
            }
        });
    </script>
</body>
</html>
