<?php include __DIR__ . '/partials/Header.php'; ?>

<div class="about-section" style="background-image: url('/public/images/about.jpg');">
    <div class="container text-center text-white">
        <h1>Quem Somos</h1>
        <p>Na Clínica Fogaça, nossa missão é cuidar de você com excelência e dedicação.</p>
    </div>
</div>
