<?php
// Simulação de carregamento de imagens (substitua por consulta real ao banco de dados ou outro recurso).
$images = [
    ['url' => 'images/image1.jpg', 'title' => 'Imagem 1', 'alt' => 'Imagem de medicina 1'],
    ['url' => 'images/image2.jpg', 'title' => 'Imagem 2', 'alt' => 'Imagem de medicina 2'],
    ['url' => 'images/image3.jpg', 'title' => 'Imagem 3', 'alt' => 'Imagem de medicina 3'],
];

// Verifica se o diretório de imagens existe (criação para simular imagens, se necessário).
if (!is_dir('images')) {
    mkdir('images', 0777, true);
    // Gera imagens de exemplo (substitua com imagens reais ou URLs externas)
    file_put_contents('images/image1.jpg', file_get_contents('https://via.placeholder.com/400x250?text=Imagem+1'));
    file_put_contents('images/image2.jpg', file_get_contents('https://via.placeholder.com/400x250?text=Imagem+2'));
    file_put_contents('images/image3.jpg', file_get_contents('https://via.placeholder.com/400x250?text=Imagem+3'));
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clínica Fogaça - Galeria</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome para ícones -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        header {
            background-color: #007bff;
            color: white;
            padding: 15px 0;
            text-align: center;
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        .gallery img {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .gallery img:hover {
            transform: scale(1.05);
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 1.5rem;
        }
        .card-body {
            background-color: #f8f9fa;
        }
        .text-muted {
            font-size: 0.8rem;
        }
        .footer-links a {
            color: #f8f9fa;
            text-decoration: none;
            margin: 0 10px;
        }
        .footer-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>Clínica Fogaça</h1>
        <p>Excelência no cuidado à saúde</p>
    </header>

    <div class="container mt-5">
        <h2 class="text-center text-primary mb-4">Galeria de Imagens Médicas</h2>
        
        <div class="row gallery">
            <?php foreach ($images as $image): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="<?= htmlspecialchars($image['url']) ?>" alt="<?= htmlspecialchars($image['alt']) ?>" class="card-img-top img-fluid">
                        <div class="card-body">
                            <h5 class="card-title text-center"><?= htmlspecialchars($image['title']) ?></h5>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header text-center">
                <i class="fas fa-user-circle"></i> Login
            </div>
            <div class="card-body">
                <form action="process-login.php" method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Nome de Usuário</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">E-mail</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Telefone</label>
                        <input type="tel" class="form-control" id="phone" name="phone" pattern="^\([0-9]{2}\)\s?[0-9]{4,5}-[0-9]{4}$" placeholder="(XX) XXXXX-XXXX" required>
                        <small class="form-text text-muted">Digite o telefone no formato (XX) XXXX-XXXX ou (XX) XXXXX-XXXX</small>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Senha</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Entrar</button>
                </form>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-links">
            <a href="#">Sobre</a>
            <a href="#">Contato</a>
            <a href="#">Privacidade</a>
        </div>
        <p class="text-muted">&copy; 2024 Clínica Fogaça. Todos os direitos reservados.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
