namespace App\Controllers;

use App\Models\User;

class UserController {
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Recebe os dados do formulário
            $username = htmlspecialchars($_POST['username']);
            $email = htmlspecialchars($_POST['email']);
            $password = $_POST['password'];
            $birthdate = htmlspecialchars($_POST['birthdate']);  // Novo campo
            $address = htmlspecialchars($_POST['address']);  // Novo campo
            
            // Validação dos campos
            if (empty($username) || empty($email) || empty($password) || empty($birthdate) || empty($address)) {
                echo "<script>
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro',
                            text: 'Por favor, preencha todos os campos.'
                        });
                      </script>";
                return;
            }
            
            // Validando o comprimento da senha (mínimo 6 e máximo 8 caracteres)
            if (strlen($password) < 6) {
                echo "<script>
                        Swal.fire({
                            icon: 'warning',
                            title: 'Atenção',
                            text: 'A senha deve ter pelo menos 6 caracteres!'
                        });
                      </script>";
                return;
            }

            if (strlen($password) > 8) { // Validando o limite máximo de 8 caracteres
                echo "<script>
                        Swal.fire({
                            icon: 'warning',
                            title: 'Atenção',
                            text: 'A senha deve ter no máximo 8 caracteres!'
                        });
                      </script>";
                return;
            }
            
            // Criando um novo usuário
            $user = new User();
            if ($user->create($username, $email, $password, $birthdate, $address)) {
                echo "<script>
                        Swal.fire({
                            icon: 'success',
                            title: 'Sucesso',
                            text: 'Usuário cadastrado com sucesso!',
                        }).then(() => {
                            window.location.href = '/';
                        });
                      </script>";
            } else {
                echo "<script>
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro',
                            text: 'Falha ao cadastrar o usuário.',
                        });
                      </script>";
            }
        }
    }
}
