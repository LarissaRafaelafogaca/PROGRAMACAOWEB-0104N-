<?php

// Captura a rota da URL (por exemplo, ?route=home) ou define um valor padrão
$route = $_GET['route'] ?? 'home'; // Use 'home' como padrão se nenhuma rota for passada

// Verifica se a rota está definida
if (!isset($route) || empty($route)) {
    echo "Nenhuma rota foi definida!";
    return;
}

// Define as rotas permitidas
$allowedRoutes = ['home', 'login', 'about', 'contact', 'headert', 'forms'];

// Verifica se a rota solicitada está na lista de rotas permitidas
if (!in_array($route, $allowedRoutes)) {
    echo "Rota inválida!";
    return;
}

// Função para lidar com as rotas
function handleRoute($route)
{
    switch ($route) {
        case 'home':
            require_once __DIR__ . '/../Views/Home.php'; // Caminho corrigido
            break;
        case 'login':
            require_once __DIR__ . '/../Views/partials/login.php'; // Caminho corrigido
            break;
        case 'about':
            require_once __DIR__ . '/../Views/About.php'; // Caminho corrigido
            break;
        case 'contact':
            require_once __DIR__ . '/../Views/Contact.php'; // Caminho corrigido
            break;
        case 'headert':
            require_once __DIR__ . '/../Views/Header.php'; // Caminho corrigido
            break;
        case 'forms':
            require_once __DIR__ . '/../Views/Forms.php'; // Caminho corrigido
            break;
        default:
            echo "Página não encontrada!";
            break;
    }
}

// Chama a função handleRoute com a rota atual
handleRoute($route);
