
<footer>
    <div class="container">

        Consultório Dra. Larissa Rafaela Fogaça - Todos os direitos reservados

    </div>
</footer>