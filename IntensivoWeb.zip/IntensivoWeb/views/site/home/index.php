<main>

    <section class="banner" id="banner">
        <!-- Banner content, e.g., an image or text -->
    </section>

    <section class="opcoes" id="opcoes">
        <div class="container">
            <h2>Opções</h2>
            <div class="row">
                <?php for ($i = 0; $i < count($images); $i++) {  ?>
                    <div class="col-md-4">
                        <div class="imagem">
                            <!-- Exibir imagem -->
                            <img src="path/to/images/<?php echo $images[$i]; ?>" alt="Imagem de serviço" class="img-fluid" />
                        </div>
                        <p>
                            Sempre preparados com alta tecnologia, e excelência em atendimento.
                        </p>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>

    <section class="quem-somos" id="quem-somos">
        <div class="container">
            <h2>Quem Somos</h2>
            <p>
                 Na Clínica Fogaça, nossa missão é oferecer um atendimento de excelência, 
                 sempre pautado pela empatia, respeito e dedicação aos nossos pacientes. 
                 Somos uma equipe de profissionais altamente qualificados e comprometidos com a saúde
                  e bem-estar de cada pessoa que nos procura.
            </p>
        </div>
    </section>

    <section class="contato" id="contato">
        <h1>Dr. Larissa Rafaela Fogaça 0104N<br>trabalhofinal@promacaoweb.com</h1> 
        <div class="container">
            <center>
                <form id="contact-form" class="formulario" action="process_contact.php" method="POST">
                    <h3>Entre em Contato</h3>
                    <br />
                    <div class="row">
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                <label>Nome</label>
                                <input class="form-control" name="nome" type="text" required />
                            </div>
                        </div>
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                <label>E-Mail</label>
                                <input class="form-control" name="email" type="email" required />
                            </div>
                        </div>
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                <label>Telefone</label>
                                <input class="form-control" name="phone" type="tel" required />
                            </div>
                        </div>
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                <label>Mensagem</label>
                                <textarea class="form-control" name="descricao" required></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="btn btn-success" id="button-test">Enviar</div>
                </form>
            </center>
        </div>
    </section>
</main>
