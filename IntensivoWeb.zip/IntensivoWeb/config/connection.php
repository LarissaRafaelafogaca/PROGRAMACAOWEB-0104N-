<?php

$config = array(
    'dns'       => 'mysql:dbname=instensivo_web;host='localhost',
    'username'  => 'root',
    'password'  => 'null',
);

if(ENV == 'prod'){
    $config['dns'] = "mysql:dbname=;host='localhost";
    $config['username'] = 'root';
    $config['password'] = 'null';
}

return $config;

?>