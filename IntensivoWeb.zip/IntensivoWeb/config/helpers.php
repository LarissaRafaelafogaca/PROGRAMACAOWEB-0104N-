<?php 

define('LOCAL_URL', '/IntensivoWeb');

return array(
    'URLHelper'     => new URLHelper,
    'AdminSession'  => new AdminSession,
);

?>