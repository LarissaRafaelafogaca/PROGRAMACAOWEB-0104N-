<?php

// Configuração do ambiente (true para desenvolvimento, false para produção)
$isDevelopment = true;

// Configurações de erro com base no ambiente
if ($isDevelopment) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $conn;

    // Construtor para carregar variáveis de ambiente
    public function __construct() {
        $this->host = getenv('DB_HOST') ?: "127.0.0.1"; // Endereço do servidor MySQL
        $this->db_name = getenv('DB_NAME') ?: "medical_system"; // Nome do banco de dados
        $this->username = getenv('DB_USER') ?: "root"; // Usuário do MySQL
        $this->password = getenv('DB_PASS') ?: ""; // Senha do MySQL
    }

    // Método para obter a conexão com o banco de dados
    public function getConnection() {
        $this->conn = null;

        try {
            // Conexão usando PDO
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name, 
                $this->username, 
                $this->password
            );

            // Configura o modo de erro para exceções
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            if (getenv('DEBUG') === 'true') {
                echo "Conexão bem-sucedida"; // Mensagem opcional para depuração
            }
        } catch (PDOException $exception) {
            // Tratamento de erros na conexão
            $this->handleError($exception);
        }

        return $this->conn;
    }

    // Método para tratar erros na conexão
    private function handleError(PDOException $exception) {
        if (getenv('DEBUG') === 'true') {
            echo "Erro na conexão: " . $exception->getMessage();
        } else {
            error_log("Erro na conexão: " . $exception->getMessage());
            echo "Erro ao conectar ao banco de dados. Tente novamente mais tarde.";
        }
    }
}

// Exemplo de uso
// Defina variáveis de ambiente antes de usar
// putenv("DB_HOST=127.0.0.1");
// putenv("DB_NAME=medical_system");
// putenv("DB_USER=root");
// putenv("DB_PASS=");
// putenv("DEBUG=true");

// $db = new Database();
// $connection = $db->getConnection();
